self.__precacheManifest = [
  {
    "revision": "ec405996c775cc397edd",
    "url": "/static/css/main.b704fd01.chunk.css"
  },
  {
    "revision": "ec405996c775cc397edd",
    "url": "/static/js/main.90acb8bd.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "bd1ece65b7949a868811",
    "url": "/static/css/2.81015f9c.chunk.css"
  },
  {
    "revision": "bd1ece65b7949a868811",
    "url": "/static/js/2.67cf2457.chunk.js"
  },
  {
    "revision": "2b1d40579eecf41696cfeafad2c09739",
    "url": "/static/media/breakfast.2b1d4057.png"
  },
  {
    "revision": "fe99c01df18304ef6b97c126249105d7",
    "url": "/static/media/water.fe99c01d.png"
  },
  {
    "revision": "6348c819ac3175d9e71542b33a86fce4",
    "url": "/index.html"
  }
];